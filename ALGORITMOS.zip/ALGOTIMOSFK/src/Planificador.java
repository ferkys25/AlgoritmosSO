import java.util.*;
import java.util.stream.Collectors;

class Proceso {
    String id;
    int rafaga, llegada, prioridad;
    int espera = 0, retorno = 0, restante;

    public Proceso(String id, int rafaga, int llegada) {
        this.id = id;
        this.rafaga = rafaga;
        this.llegada = llegada;
        this.prioridad = -1; // No aplica
        this.restante = rafaga;
    }

    public Proceso(String id, int rafaga, int llegada, int prioridad) {
        this.id = id;
        this.rafaga = rafaga;
        this.llegada = llegada;
        this.prioridad = prioridad;
        this.restante = rafaga;
    }
}

public class Planificador {

    static Scanner sc = new Scanner(System.in);
    static List<Proceso> procesos = new ArrayList<>();

    public static void main(String[] args) {
        int opcion;

        do {
            System.out.println("\n--- MENÚ DE PLANIFICACIÓN ---");
            System.out.println("1. FIFO");
            System.out.println("2. SJF (Shortest Job First)");
            System.out.println("3. Prioridad");
            System.out.println("4. Round Robin");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();

            procesos.clear();
            switch (opcion) {
                case 1 -> {
                    ingresarProcesos(false);
                    fifo();
                }
                case 2 -> {
                    ingresarProcesos(false);
                    sjf();
                }
                case 3 -> {
                    ingresarProcesos(true);
                    prioridad();
                }
                case 4 -> {
                    ingresarProcesos(true);
                    System.out.print("Ingrese el quantum: ");
                    int quantum = sc.nextInt();
                    roundRobinConPrioridad(procesos, quantum);
                }
                case 5 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción inválida");
            }

        } while (opcion != 5);
    }

    static void ingresarProcesos(boolean conPrioridad) {
        System.out.println("\n--- INGRESO DE PROCESOS ---");
        for (int i = 0; i < 5; i++) {
            System.out.println("Proceso " + (i + 1));
            System.out.print("ID: ");
            String id = sc.next();
            System.out.print("Ráfaga CPU: ");
            int rafaga = sc.nextInt();
            System.out.print("Tiempo de llegada: ");
            int llegada = sc.nextInt();
            if (conPrioridad) {
                System.out.print("Prioridad (menor número = más prioridad): ");
                int prioridad = sc.nextInt();
                procesos.add(new Proceso(id, rafaga, llegada, prioridad));
            } else {
                procesos.add(new Proceso(id, rafaga, llegada));
            }
        }
    }

    static void fifo() {
        System.out.println("\n--- FIFO ---");
        List<Proceso> lista = new ArrayList<>(procesos);
        lista.sort(Comparator.comparingInt(p -> p.llegada));

        int tiempo = 0;
        for (Proceso p : lista) {
            if (tiempo < p.llegada) tiempo = p.llegada;
            p.espera = tiempo - p.llegada;
            tiempo += p.rafaga;
            p.retorno = tiempo;
        }
        imprimirResultados(lista);
    }

    static void sjf() {
        System.out.println("\n--- SJF ---");
        List<Proceso> lista = new ArrayList<>();
        List<Proceso> cola = new ArrayList<>(procesos);

        int tiempo = 0;
        while (!cola.isEmpty()) {
            int finalTiempo = tiempo;
            List<Proceso> disponibles = cola.stream()
                    .filter(p -> p.llegada <= finalTiempo)
                    .collect(Collectors.toList());

            if (disponibles.isEmpty()) {
                tiempo++;
                continue;
            }

            disponibles.sort(Comparator.comparingInt(p -> p.rafaga));
            Proceso actual = disponibles.get(0);
            cola.remove(actual);

            actual.espera = tiempo - actual.llegada;
            tiempo += actual.rafaga;
            actual.retorno = tiempo;
            lista.add(actual);
        }
        imprimirResultados(lista);
    }

    static void prioridad() {
        System.out.println("\n--- PRIORIDAD ---");
        List<Proceso> lista = new ArrayList<>();
        List<Proceso> cola = new ArrayList<>(procesos);

        int tiempo = 0;
        while (!cola.isEmpty()) {
            int finalTiempo = tiempo;
            List<Proceso> disponibles = cola.stream()
                    .filter(p -> p.llegada <= finalTiempo)
                    .sorted(Comparator
                            .comparingInt((Proceso p) -> p.prioridad)
                            .thenComparingInt(p -> p.llegada))
                    .collect(Collectors.toList());

            if (disponibles.isEmpty()) {
                tiempo++;
                continue;
            }

            Proceso actual = disponibles.get(0);
            cola.remove(actual);

            actual.espera = tiempo - actual.llegada;
            tiempo += actual.rafaga;
            actual.retorno = tiempo;
            lista.add(actual);
        }
        imprimirResultados(lista);
    }

    static void roundRobinConPrioridad(List<Proceso> procesos, int quantum) {
        System.out.println("\n--- ROUND ROBIN CON PRIORIDAD ---");

        int tiempo = 0;
        List<Proceso> listos = new ArrayList<>();
        List<Proceso> completados = new ArrayList<>();
        List<Proceso> pendientes = new ArrayList<>(procesos);

        Map<Proceso, Integer> restante = new HashMap<>();
        for (Proceso p : procesos) {
            restante.put(p, p.rafaga);
        }

        while (completados.size() < procesos.size()) {
            // Agregar procesos que ya llegaron al tiempo actual
            int finalTiempo = tiempo;
            List<Proceso> nuevos = pendientes.stream()
                    .filter(p -> p.llegada <= finalTiempo)
                    .collect(Collectors.toList());

            listos.addAll(nuevos);
            pendientes.removeAll(nuevos);

            if (listos.isEmpty()) {
                tiempo++;
                continue;
            }

            // Ordenar por prioridad y llegada
            listos.sort(Comparator
                    .comparingInt((Proceso p) -> p.prioridad)
                    .thenComparingInt(p -> p.llegada));

            Proceso actual = listos.remove(0);
            int ejecucion = Math.min(quantum, restante.get(actual));

            tiempo += ejecucion;
            restante.put(actual, restante.get(actual) - ejecucion);

            // Ver si llegaron nuevos procesos mientras se ejecutaba este
            int nuevoTiempo = tiempo;
            nuevos = pendientes.stream()
                    .filter(p -> p.llegada <= nuevoTiempo)
                    .collect(Collectors.toList());

            listos.addAll(nuevos);
            pendientes.removeAll(nuevos);

            if (restante.get(actual) > 0) {
                listos.add(actual); // Reinserta si no terminó
            } else {
                actual.retorno = tiempo;
                actual.espera = actual.retorno - actual.llegada - actual.rafaga;
                completados.add(actual);
            }
        }

        imprimirResultados(completados);
    }


    static void imprimirResultados(List<Proceso> lista) {
        double totalEspera = 0, totalRetorno = 0;

        System.out.println("\nID\tLlegada\tRáfaga\tEspera\tRetorno");
        for (Proceso p : lista) {
            System.out.printf("%s\t%d\t%d\t%d\t%d\n", p.id, p.llegada, p.rafaga, p.espera, p.retorno);
            totalEspera += p.espera;
            totalRetorno += p.retorno;
        }

        System.out.printf("Tiempo medio de espera: %.2f\n", totalEspera / lista.size());
        System.out.printf("Tiempo medio de retorno: %.2f\n", totalRetorno / lista.size());
    }
}